import React, { useState } from 'react'

const App = () => {
  const [Weight, setWeight] = useState('');
  const [Height, setHeight] = useState('');
  const [Bmi, setBmi] = useState('');
  const [Msg, setMsg] = useState('');

  const calculate = (e) =>{
    e.preventDefault();
    if(Weight && Height){
      let value = (Weight/(Height*Height)*703);
      setBmi(`Your Bmi is ${value.toFixed(1)} and `);
      //alert(`Your BMI is: ${bmi}`);
      if(value < 19){
        setMsg('You are underweight');
      }else if(value >=25 && value < 30){
        setMsg('You are Healthy');
      }else{
        setMsg('You are Overweight');
      }
    } else {
      alert('Please enter both weight and height');
    }

  }
  return (
    <>
    <h1>BMI CALCULATOR</h1>
    <form onSubmit={calculate}>
      <label htmlFor="">Weight in (kg) <span>*</span></label>
        <input type="text" placeholder='Weight' onChange={(e) => setWeight(e.target.value)} value={Weight}/>
        <label htmlFor="">Height in (Inches) <span>*</span></label>
        <input type="text" placeholder='Height' onChange={(e) => setHeight(e.target.value)} value={Height}/>
        <button className='submit'>Calculate</button>
        <p>{Bmi}{Msg}</p>
    </form>
    </>
  )
}

export default App